package com.example.project1.service;

import com.example.project1.model.Course;
import com.example.project1.model.Student;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class StudentService {
    private static final List<Student> students = new ArrayList<>();
    public List<Course> retrieveCourses(String firstName) {
        return new ArrayList<>();
    }

    public List<Student> getAllStudents() throws IOException {
        ObjectMapper om = new ObjectMapper();
        Student[] studentArray = om.readValue(new URL("https://hccs-advancejava.s3.amazonaws.com/student_course.json"), Student[].class);
        Collections.addAll(students, studentArray);
        return students;
    }

    public Student getStudentByNameAndCourse(String firstName, String courseNo) throws IOException {
        List<Student> students = getAllStudents();
        double gpa = 0;
        Student student =  students.stream()
                .filter(s -> s.getFirstName().equals(firstName))
                .findAny().orElse(null);

        if (student != null && student.getCourse() != null) {
            Course course =  student.getCourse().stream().filter(c -> c.getCourseNo().equals(courseNo)).findAny().orElse(null);
            System.out.println("Student Name = " + student.getFirstName() + " | Course = "  + course.getCourseNo());
            calculateGpa();
        }
        return student;

    }

    public void calculateGpa() throws IOException {
        List<Student> students = getAllStudents();
        double gpa = 0;

        for (Student student : students) {
            long totalGradePoint = 0;
            if (student.getCourse() != null) {
                for (Course course : student.getCourse()) {
                    switch (course.getGrade()) {
                        case "A":
                            totalGradePoint = totalGradePoint + 4;
                            break;
                        case "B":
                            totalGradePoint = totalGradePoint + 3;
                            break;
                        case "C":
                            totalGradePoint = totalGradePoint + 2;
                            break;
                        case "D":
                            totalGradePoint = totalGradePoint + 1;
                            break;
                        default:
                    }
                }
                gpa = (double) totalGradePoint / student.getCourse().size();
            }

            System.out.println("Student Name = " + student.getFirstName() + " | GPA = "  + gpa);
        }
    }

}
