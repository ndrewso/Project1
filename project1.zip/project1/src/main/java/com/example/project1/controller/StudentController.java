package com.example.project1.controller;

import com.example.project1.model.Course;
import com.example.project1.model.Student;
import com.example.project1.service.StudentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/students")
    public Student getStudentByNameAndCourse(@RequestParam(name = "firstName") String firstName, @RequestParam String courseNo) throws IOException {
        return  studentService.getStudentByNameAndCourse(firstName, courseNo);
    }

    //@GetMapping("/students")
    public List<Student> getAllStudents() throws IOException {
        return studentService.getAllStudents();
    }
}
