package com.example.project1.model;

public class Course {
    private String courseNo;
    private String grade;
    private long creditHours;

    public String getCourseNo() { return courseNo; }
    public void setCourseNo(String value) { this.courseNo = value; }

    public String getGrade() { return grade; }
    public void setGrade(String value) { this.grade = value; }

    public long getCreditHours() { return creditHours; }
    public void setCreditHours(long value) { this.creditHours = value; }
}
