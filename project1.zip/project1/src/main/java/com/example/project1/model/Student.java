package com.example.project1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class Student {
    private long id;
    @JsonProperty("first_name")
    private String firstName;
    private String email;
    private String gender;
    private List<Course> course;

    public long getID() { return id; }
    public void setID(long value) { this.id = value; }


    public String getFirstName() { return firstName; }
    public void setFirstName(String value) { this.firstName = value; }

    public String getEmail() { return email; }
    public void setEmail(String value) { this.email = value; }

    public String getGender() { return gender; }
    public void setGender(String value) { this.gender = value; }

    public List<Course> getCourse() { return course; }
    public void setCourse(List<Course> value) { this.course = value; }
}
